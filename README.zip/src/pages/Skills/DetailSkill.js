import styles from "./DetailSkill.module.scss"

const DetailSkill = ()=>{
    <div className={styles.container}></div>
}

export default DetailSkill;